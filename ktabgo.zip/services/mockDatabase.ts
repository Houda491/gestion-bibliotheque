import { Book, Reservation, User, UserRole } from '../types';

// Initial Data with High Quality Images
const INITIAL_BOOKS: Book[] = [
  {
    id: '1',
    title: 'Les Misérables',
    author: 'Victor Hugo',
    category: 'Classique',
    description: "L'histoire poignante de Jean Valjean, ancien forçat en quête de rédemption dans la France du XIXe siècle. Une fresque sociale et historique monumentale.",
    coverUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=800',
    totalCopies: 5,
    availableCopies: 3
  },
  {
    id: '2',
    title: 'L\'Étranger',
    author: 'Albert Camus',
    category: 'Philosophie',
    description: "Meursault, un homme étranger aux conventions sociales et à ses propres émotions, commet un crime irréparable sous le soleil d'Alger.",
    coverUrl: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=800',
    totalCopies: 3,
    availableCopies: 1
  },
  {
    id: '3',
    title: 'Le Petit Prince',
    author: 'Antoine de Saint-Exupéry',
    category: 'Jeunesse',
    description: 'Un conte poétique et philosophique sur la rencontre entre un pilote échoué dans le désert et un petit prince venu d\'une autre planète.',
    coverUrl: 'https://images.unsplash.com/photo-1633477189729-9290b3261d0a?auto=format&fit=crop&q=80&w=800',
    totalCopies: 10,
    availableCopies: 8
  },
  {
    id: '4',
    title: '1984',
    author: 'George Orwell',
    category: 'Science-Fiction',
    description: 'Dans un monde totalitaire surveillé par Big Brother, Winston Smith tente de résister à l\'oppression et à la réécriture de l\'histoire.',
    coverUrl: 'https://images.unsplash.com/photo-1535905557558-afc4877a26fc?auto=format&fit=crop&q=80&w=800',
    totalCopies: 4,
    availableCopies: 0
  },
  {
    id: '5',
    title: 'Harry Potter à l\'école des sorciers',
    author: 'J.K. Rowling',
    category: 'Fantastique',
    description: 'Un jeune orphelin découvre le jour de ses onze ans qu\'il possède des pouvoirs magiques et rejoint l\'école de Poudlard.',
    coverUrl: 'https://images.unsplash.com/photo-1626618012641-bfbca5a31239?auto=format&fit=crop&q=80&w=800',
    totalCopies: 7,
    availableCopies: 7
  },
  {
    id: '6',
    title: 'Orgueil et Préjugés',
    author: 'Jane Austen',
    category: 'Romance',
    description: 'Une histoire d\'amour et de malentendus dans l\'Angleterre de la Régence, centrée sur la spirituelle Elizabeth Bennet et le sombre M. Darcy.',
    coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=800',
    totalCopies: 6,
    availableCopies: 5
  },
  {
    id: '7',
    title: 'Le Seigneur des Anneaux',
    author: 'J.R.R. Tolkien',
    category: 'Fantasy',
    description: 'Frodon Sacquet entreprend un voyage périlleux pour détruire l\'Anneau Unique et sauver la Terre du Milieu des ténèbres.',
    coverUrl: 'https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?auto=format&fit=crop&q=80&w=800',
    totalCopies: 4,
    availableCopies: 2
  },
  {
    id: '8',
    title: 'Dune',
    author: 'Frank Herbert',
    category: 'Science-Fiction',
    description: 'Paul Atreides doit naviguer entre intrigues politiques et prophéties mystiques sur la planète désertique Arrakis.',
    coverUrl: 'https://images.unsplash.com/photo-1541963463532-d68292c34b19?auto=format&fit=crop&q=80&w=800',
    totalCopies: 8,
    availableCopies: 6
  }
];

const INITIAL_USERS: User[] = [
  {
    id: 'admin1',
    name: 'Administrateur',
    email: 'admin@ktabgo.ma',
    password: 'admin',
    role: UserRole.ADMIN,
    registeredAt: new Date().toISOString()
  },
  {
    id: 'user1',
    name: 'Jean Dupont',
    email: 'jean@test.fr',
    password: 'user',
    role: UserRole.USER,
    registeredAt: new Date().toISOString()
  }
];

const STORAGE_KEYS = {
  BOOKS: 'biblio_books',
  USERS: 'biblio_users',
  RESERVATIONS: 'biblio_reservations'
};

// Helpers to simulate DB latency
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const db = {
  init: () => {
    if (!localStorage.getItem(STORAGE_KEYS.BOOKS)) {
      localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(INITIAL_BOOKS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.RESERVATIONS)) {
      localStorage.setItem(STORAGE_KEYS.RESERVATIONS, JSON.stringify([]));
    }
  },

  getBooks: async (): Promise<Book[]> => {
    await delay(300);
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKS) || '[]');
  },

  saveBook: async (book: Book): Promise<void> => {
    await delay(300);
    const books: Book[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKS) || '[]');
    const index = books.findIndex(b => b.id === book.id);
    if (index >= 0) {
      books[index] = book;
    } else {
      books.push(book);
    }
    localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books));
  },

  deleteBook: async (id: string): Promise<void> => {
    await delay(300);
    const books: Book[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKS) || '[]');
    const newBooks = books.filter(b => b.id !== id);
    localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(newBooks));
  },

  getUsers: async (): Promise<User[]> => {
    await delay(300);
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
  },

  createUser: async (user: User): Promise<void> => {
    await delay(300);
    const users: User[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    if (users.find(u => u.email === user.email)) {
      throw new Error("Cet email est déjà utilisé.");
    }
    users.push(user);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  },

  getReservations: async (): Promise<Reservation[]> => {
    await delay(300);
    const res: Reservation[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.RESERVATIONS) || '[]');
    // Join with book and user data for display
    const books = await db.getBooks();
    const users = await db.getUsers();
    
    return res.map(r => ({
      ...r,
      bookTitle: books.find(b => b.id === r.bookId)?.title || 'Livre inconnu',
      userName: users.find(u => u.id === r.userId)?.name || 'Utilisateur inconnu'
    }));
  },

  createReservation: async (userId: string, bookId: string): Promise<void> => {
    await delay(300);
    const books: Book[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKS) || '[]');
    const bookIndex = books.findIndex(b => b.id === bookId);
    
    if (bookIndex === -1) throw new Error("Livre non trouvé");
    if (books[bookIndex].availableCopies <= 0) throw new Error("Plus de copies disponibles");

    books[bookIndex].availableCopies -= 1;
    localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books));

    const reservations: Reservation[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.RESERVATIONS) || '[]');
    const newReservation: Reservation = {
      id: Date.now().toString(),
      userId,
      bookId,
      date: new Date().toISOString(),
      status: 'active'
    };
    reservations.push(newReservation);
    localStorage.setItem(STORAGE_KEYS.RESERVATIONS, JSON.stringify(reservations));
  },

  returnBook: async (reservationId: string): Promise<void> => {
    await delay(300);
    const reservations: Reservation[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.RESERVATIONS) || '[]');
    const resIndex = reservations.findIndex(r => r.id === reservationId);
    
    if (resIndex === -1) throw new Error("Réservation non trouvée");
    
    const reservation = reservations[resIndex];
    if (reservation.status === 'returned') return;

    reservation.status = 'returned';
    reservations[resIndex] = reservation;
    localStorage.setItem(STORAGE_KEYS.RESERVATIONS, JSON.stringify(reservations));

    const books: Book[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.BOOKS) || '[]');
    const bookIndex = books.findIndex(b => b.id === reservation.bookId);
    if (bookIndex !== -1) {
      books[bookIndex].availableCopies += 1;
      localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books));
    }
  }
};
