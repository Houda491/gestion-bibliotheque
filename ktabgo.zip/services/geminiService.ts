import { GoogleGenAI } from "@google/genai";
import { Book } from "../types";

const API_KEY = process.env.API_KEY || ''; 

// Fallback if no key is present to prevent crashing, though functionality will be limited
const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getLibrarianResponse = async (userQuery: string, catalog: Book[]): Promise<string> => {
  if (!API_KEY) {
    return "Désolé, ma configuration API est manquante. Je ne peux pas vous répondre pour le moment.";
  }

  // Create a context string from the catalog
  const catalogContext = catalog.map(b => 
    `- Titre: ${b.title}, Auteur: ${b.author}, Catégorie: ${b.category}, Copies dispo: ${b.availableCopies}`
  ).join('\n');

  const systemInstruction = `
    Vous êtes un bibliothécaire virtuel français serviable, cultivé et poli nommé "Gémilio".
    Votre but est d'aider les utilisateurs à choisir des livres parmi le catalogue de la bibliothèque ci-dessous.
    
    Règles:
    1. Répondez toujours en français.
    2. Basez vos recommandations UNIQUEMENT sur les livres du catalogue fourni ci-dessous.
    3. Si un utilisateur demande un livre qui n'est pas dans la liste, excusez-vous et proposez un livre similaire du catalogue.
    4. Indiquez si le livre est disponible ou non (basé sur 'Copies dispo').
    5. Soyez concis mais chaleureux.
    
    CATALOGUE ACTUEL:
    ${catalogContext}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userQuery,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      }
    });

    return response.text || "Je suis désolé, je n'ai pas pu formuler de réponse.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Une erreur est survenue lors de la consultation de mes fiches. Veuillez réessayer plus tard.";
  }
};
