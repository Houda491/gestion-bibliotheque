import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { db } from '../services/mockDatabase';
import { Book } from '../types';
import { useAuth } from '../context/AuthContext';
import { ArrowLeft, BookOpen, Calendar, CheckCircle, XCircle, User as UserIcon } from 'lucide-react';

const BookDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [book, setBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [reserving, setReserving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    const fetchBook = async () => {
      if (!id) return;
      const books = await db.getBooks();
      const found = books.find(b => b.id === id);
      setBook(found || null);
      setLoading(false);
    };
    fetchBook();
  }, [id]);

  const handleReserve = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!book) return;

    setReserving(true);
    setMessage(null);
    try {
      await db.createReservation(user.id, book.id);
      setMessage({ type: 'success', text: 'Réservation confirmée avec succès ! Vous pouvez récupérer votre livre.' });
      setBook({ ...book, availableCopies: book.availableCopies - 1 });
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message || "Erreur lors de la réservation." });
    } finally {
      setReserving(false);
    }
  };

  if (loading) return <div className="flex justify-center p-20"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div></div>;
  if (!book) return <div className="text-center p-20 text-stone-600">Livre non trouvé.</div>;

  return (
    <div className="max-w-5xl mx-auto">
      <button onClick={() => navigate(-1)} className="mb-6 text-stone-500 hover:text-brand-700 flex items-center gap-2 text-sm font-medium transition-colors">
        <ArrowLeft size={18} /> Retour au catalogue
      </button>

      <div className="bg-white rounded-3xl shadow-xl border border-brand-100 overflow-hidden">
        <div className="grid md:grid-cols-12 gap-0">
          {/* Cover Image */}
          <div className="md:col-span-5 h-[400px] md:h-auto bg-stone-100 relative group overflow-hidden">
            <img 
              src={book.coverUrl} 
              alt={book.title} 
              className="w-full h-full object-cover transition-transform duration-700 hover:scale-105" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent md:hidden"></div>
          </div>

          {/* Details */}
          <div className="md:col-span-7 p-8 md:p-12 flex flex-col">
            <div className="mb-4">
              <span className="bg-brand-100 text-brand-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">{book.category}</span>
            </div>
            
            <h1 className="text-4xl font-serif font-bold text-brand-900 mb-2 leading-tight">{book.title}</h1>
            <div className="flex items-center gap-2 text-xl text-stone-600 mb-8">
              <UserIcon size={20} className="text-brand-400" />
              <span className="font-medium">{book.author}</span>
            </div>
            
            <div className="prose prose-stone text-stone-600 mb-8 leading-relaxed">
              <p>{book.description}</p>
            </div>

            <div className="mt-auto space-y-6">
              <div className="flex items-center gap-8 p-4 bg-brand-50 rounded-xl border border-brand-100">
                <div className="flex flex-col">
                  <span className="text-xs text-stone-500 uppercase font-bold tracking-wider mb-1">Stock Total</span>
                  <div className="flex items-center gap-2 text-brand-900 font-bold text-lg">
                    <BookOpen size={20} className="text-brand-500" />
                    <span>{book.totalCopies} copies</span>
                  </div>
                </div>
                <div className="w-px h-10 bg-brand-200"></div>
                <div className="flex flex-col">
                  <span className="text-xs text-stone-500 uppercase font-bold tracking-wider mb-1">Disponibilité</span>
                  <div className={`flex items-center gap-2 font-bold text-lg ${book.availableCopies > 0 ? 'text-green-700' : 'text-red-700'}`}>
                    {book.availableCopies > 0 ? <CheckCircle size={20} /> : <XCircle size={20} />}
                    <span>{book.availableCopies} en rayon</span>
                  </div>
                </div>
              </div>

              {message && (
                <div className={`p-4 rounded-lg text-sm border ${message.type === 'success' ? 'bg-green-50 text-green-800 border-green-100' : 'bg-red-50 text-red-800 border-red-100'}`}>
                  {message.text}
                </div>
              )}

              <button
                onClick={handleReserve}
                disabled={book.availableCopies <= 0 || reserving}
                className="w-full py-4 bg-brand-700 text-white font-bold rounded-xl hover:bg-brand-800 transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none disabled:transform-none flex justify-center items-center gap-2 text-lg"
              >
                {book.availableCopies > 0 ? (
                  <>
                    <Calendar size={22} />
                    {reserving ? 'Traitement en cours...' : 'Réserver cet ouvrage'}
                  </>
                ) : (
                  'Actuellement indisponible'
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookDetails;
