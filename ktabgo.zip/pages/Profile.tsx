import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { db } from '../services/mockDatabase';
import { Reservation } from '../types';
import { Calendar, Book as BookIcon, User as UserIcon } from 'lucide-react';
import { Navigate } from 'react-router-dom';

const Profile: React.FC = () => {
  const { user } = useAuth();
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReservations = async () => {
      if (!user) return;
      const allRes = await db.getReservations();
      // Filter for current user only
      const userRes = allRes.filter(r => r.userId === user.id);
      // Sort by date desc
      setReservations(userRes.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setLoading(false);
    };
    fetchReservations();
  }, [user]);

  if (!user) return <Navigate to="/login" />;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-8">
        <div className="flex items-center gap-4 mb-8">
            <div className="p-3 bg-brand-100 rounded-full text-brand-700">
                <UserIcon size={32} />
            </div>
            <div>
                <h2 className="text-2xl font-serif font-bold text-brand-900">Mon Espace Membre</h2>
                <p className="text-stone-500">Gérez vos informations et vos emprunts</p>
            </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 bg-brand-50/50 rounded-xl border border-brand-100/50">
          <div>
            <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1">Nom complet</label>
            <div className="text-lg font-medium text-brand-900">{user.name}</div>
          </div>
          <div>
            <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1">Email</label>
            <div className="text-lg font-medium text-brand-900">{user.email}</div>
          </div>
          <div>
            <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1">Statut</label>
            <div className="mt-1">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-brand-200 text-brand-800 uppercase tracking-wide">
                {user.role}
              </span>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1">Membre depuis</label>
            <div className="text-lg font-medium text-brand-900">{new Date(user.registeredAt).toLocaleDateString('fr-FR')}</div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-brand-100 overflow-hidden">
        <div className="px-8 py-6 border-b border-brand-100 bg-brand-50/30">
          <h3 className="text-xl font-serif font-bold text-brand-900">Historique des Réservations</h3>
        </div>
        
        {loading ? (
          <div className="p-12 text-center text-stone-500">Chargement de votre historique...</div>
        ) : reservations.length === 0 ? (
          <div className="p-12 text-center">
            <div className="inline-flex justify-center items-center w-12 h-12 rounded-full bg-stone-100 text-stone-400 mb-3">
                <BookIcon size={24} />
            </div>
            <p className="text-stone-500">Vous n'avez aucune réservation pour le moment.</p>
          </div>
        ) : (
          <ul className="divide-y divide-brand-100">
            {reservations.map(res => (
              <li key={res.id} className="p-6 hover:bg-brand-50/50 transition-colors">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-xl ${res.status === 'active' ? 'bg-brand-100 text-brand-700' : 'bg-stone-100 text-stone-500'}`}>
                      <BookIcon size={24} />
                    </div>
                    <div>
                      <h4 className="text-lg font-serif font-bold text-brand-900">{res.bookTitle}</h4>
                      <div className="flex items-center gap-2 text-sm text-stone-500 mt-1">
                        <Calendar size={14} />
                        Réservé le {new Date(res.date).toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })}
                      </div>
                    </div>
                  </div>
                  <div>
                    <span className={`px-4 py-1.5 rounded-full text-sm font-bold shadow-sm ${
                      res.status === 'active' 
                        ? 'bg-green-100 text-green-800 border border-green-200' 
                        : 'bg-stone-100 text-stone-600 border border-stone-200'
                    }`}>
                      {res.status === 'active' ? 'En cours' : 'Retourné'}
                    </span>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Profile;
