import React from 'react';
import { Link } from 'react-router-dom';
import { Book, Users, Clock, ArrowRight, Library, Star } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <div className="relative rounded-3xl overflow-hidden shadow-2xl bg-brand-900 text-white min-h-[500px] flex items-center">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 hover:scale-105" 
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1507842217121-9e96e4715002?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80)' }} 
        />
        <div className="absolute inset-0 bg-gradient-to-r from-brand-900/95 via-brand-900/80 to-transparent"></div>
        
        <div className="relative px-8 py-16 sm:px-12 lg:px-16 max-w-2xl">
          <div className="flex items-center gap-2 text-brand-300 font-medium mb-4 tracking-wide uppercase text-sm">
            <Library size={16} />
            <span>Bienvenue sur KtabGo</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-serif font-bold tracking-tight mb-6 leading-tight">
            Votre passeport pour <span className="text-brand-300">l'imaginaire</span>
          </h1>
          <p className="text-lg text-brand-100 mb-8 leading-relaxed">
            Plongez dans notre vaste collection de classiques et de nouveautés. Une expérience de lecture moderne dans un cadre intemporel.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link 
              to="/catalog" 
              className="px-8 py-4 bg-white text-brand-900 font-bold rounded-lg hover:bg-brand-50 transition-all transform hover:-translate-y-1 shadow-lg flex items-center gap-2"
            >
              Parcourir le Catalogue <ArrowRight size={20} />
            </Link>
            <Link 
              to="/register" 
              className="px-8 py-4 border-2 border-brand-200 text-brand-100 font-bold rounded-lg hover:bg-brand-800/50 hover:text-white transition-all"
            >
              Devenir Membre
            </Link>
          </div>
        </div>
      </div>

      {/* Stats / Info Strip */}
      <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-8 grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-brand-100">
        <div>
          <div className="text-3xl font-serif font-bold text-brand-600 mb-1">5000+</div>
          <div className="text-sm text-stone-500 uppercase tracking-wider">Livres</div>
        </div>
        <div>
          <div className="text-3xl font-serif font-bold text-brand-600 mb-1">1200+</div>
          <div className="text-sm text-stone-500 uppercase tracking-wider">Membres</div>
        </div>
        <div>
          <div className="text-3xl font-serif font-bold text-brand-600 mb-1">24/7</div>
          <div className="text-sm text-stone-500 uppercase tracking-wider">Accès Digital</div>
        </div>
        <div>
          <div className="text-3xl font-serif font-bold text-brand-600 mb-1">100%</div>
          <div className="text-sm text-stone-500 uppercase tracking-wider">Gratuit</div>
        </div>
      </div>

      {/* Features */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <h2 className="text-3xl font-serif font-bold text-brand-900 mb-4">Pourquoi choisir KtabGo ?</h2>
        <p className="text-stone-600">Nous offrons bien plus que des livres. Nous offrons une expérience culturelle complète.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-xl shadow-sm border border-brand-100 hover:shadow-md transition-shadow group">
          <div className="w-14 h-14 bg-brand-50 rounded-full flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
            <Book size={28} />
          </div>
          <h3 className="text-xl font-bold text-brand-900 mb-3 font-serif">Vaste Collection</h3>
          <p className="text-stone-600 leading-relaxed">
            Accédez à des milliers d'ouvrages, des grands classiques de la littérature aux dernières parutions contemporaines.
          </p>
        </div>
        
        <div className="bg-white p-8 rounded-xl shadow-sm border border-brand-100 hover:shadow-md transition-shadow group">
          <div className="w-14 h-14 bg-brand-50 rounded-full flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
            <Star size={28} />
          </div>
          <h3 className="text-xl font-bold text-brand-900 mb-3 font-serif">IA Bibliothécaire</h3>
          <p className="text-stone-600 leading-relaxed">
            Profitez des recommandations personnalisées de "Gémilio", notre assistant intelligent disponible pour vous guider.
          </p>
        </div>
        
        <div className="bg-white p-8 rounded-xl shadow-sm border border-brand-100 hover:shadow-md transition-shadow group">
          <div className="w-14 h-14 bg-brand-50 rounded-full flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
            <Clock size={28} />
          </div>
          <h3 className="text-xl font-bold text-brand-900 mb-3 font-serif">Gestion Facile</h3>
          <p className="text-stone-600 leading-relaxed">
            Réservez vos livres en ligne en quelques clics et suivez vos emprunts via votre espace personnel intuitif.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;
