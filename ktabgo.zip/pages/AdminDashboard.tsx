import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { db } from '../services/mockDatabase';
import { Book, Reservation, User, UserRole } from '../types';
import { Navigate } from 'react-router-dom';
import { Plus, Trash2, RotateCcw, BarChart3, Book as BookIcon, Users, Calendar } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'stats' | 'books' | 'reservations'>('stats');
  
  // Data State
  const [stats, setStats] = useState({ books: 0, users: 0, reservations: 0 });
  const [books, setBooks] = useState<Book[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [refresh, setRefresh] = useState(0); // Trigger reload

  // Form State
  const [showAddBook, setShowAddBook] = useState(false);
  const [newBook, setNewBook] = useState<Partial<Book>>({
    title: '', author: '', category: '', description: '', totalCopies: 1
  });

  useEffect(() => {
    const loadData = async () => {
      const b = await db.getBooks();
      const u = await db.getUsers();
      const r = await db.getReservations();
      
      setBooks(b);
      setReservations(r.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setStats({
        books: b.length,
        users: u.length,
        reservations: r.filter(res => res.status === 'active').length
      });
    };
    loadData();
  }, [refresh]);

  if (!user || user.role !== UserRole.ADMIN) {
    return <Navigate to="/" />;
  }

  const handleDeleteBook = async (id: string) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer ce livre ?")) {
      await db.deleteBook(id);
      setRefresh(prev => prev + 1);
    }
  };

  const handleReturnBook = async (resId: string) => {
    await db.returnBook(resId);
    setRefresh(prev => prev + 1);
  };

  const handleCreateBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBook.title || !newBook.author) return;
    
    const bookToAdd: Book = {
      id: Date.now().toString(),
      title: newBook.title!,
      author: newBook.author!,
      category: newBook.category || 'Général',
      description: newBook.description || 'Pas de description.',
      coverUrl: `https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=800`, // Default neat cover
      totalCopies: Number(newBook.totalCopies),
      availableCopies: Number(newBook.totalCopies)
    };
    
    await db.saveBook(bookToAdd);
    setShowAddBook(false);
    setNewBook({ title: '', author: '', category: '', description: '', totalCopies: 1 });
    setRefresh(prev => prev + 1);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
           <h2 className="text-3xl font-serif font-bold text-brand-900">Administration</h2>
           <p className="text-stone-500">Gestion globale de la bibliothèque</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-brand-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('stats')}
            className={`${activeTab === 'stats' ? 'border-brand-600 text-brand-800' : 'border-transparent text-stone-500 hover:text-stone-700 hover:border-brand-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition-colors`}
          >
            <BarChart3 size={18} /> Vue d'ensemble
          </button>
          <button
            onClick={() => setActiveTab('books')}
            className={`${activeTab === 'books' ? 'border-brand-600 text-brand-800' : 'border-transparent text-stone-500 hover:text-stone-700 hover:border-brand-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition-colors`}
          >
            <BookIcon size={18} /> Gestion des Livres
          </button>
          <button
            onClick={() => setActiveTab('reservations')}
            className={`${activeTab === 'reservations' ? 'border-brand-600 text-brand-800' : 'border-transparent text-stone-500 hover:text-stone-700 hover:border-brand-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition-colors`}
          >
            <Calendar size={18} /> Suivi des Réservations
          </button>
        </nav>
      </div>

      {/* Content */}
      <div className="py-2">
        {activeTab === 'stats' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white overflow-hidden shadow-sm rounded-xl border border-brand-100">
              <div className="p-6 flex items-center">
                <div className="flex-shrink-0 bg-brand-100 rounded-lg p-4">
                  <Users className="h-8 w-8 text-brand-700" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-stone-500 truncate uppercase tracking-wide">Membres Inscrits</dt>
                    <dd className="text-3xl font-serif font-bold text-brand-900">{stats.users}</dd>
                  </dl>
                </div>
              </div>
            </div>
            <div className="bg-white overflow-hidden shadow-sm rounded-xl border border-brand-100">
              <div className="p-6 flex items-center">
                <div className="flex-shrink-0 bg-brand-100 rounded-lg p-4">
                  <BookIcon className="h-8 w-8 text-brand-700" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-stone-500 truncate uppercase tracking-wide">Ouvrages</dt>
                    <dd className="text-3xl font-serif font-bold text-brand-900">{stats.books}</dd>
                  </dl>
                </div>
              </div>
            </div>
            <div className="bg-white overflow-hidden shadow-sm rounded-xl border border-brand-100">
              <div className="p-6 flex items-center">
                <div className="flex-shrink-0 bg-amber-100 rounded-lg p-4">
                  <Calendar className="h-8 w-8 text-amber-700" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-stone-500 truncate uppercase tracking-wide">Emprunts Actifs</dt>
                    <dd className="text-3xl font-serif font-bold text-brand-900">{stats.reservations}</dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'books' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-serif font-bold text-brand-900">Catalogue</h3>
              <button 
                onClick={() => setShowAddBook(!showAddBook)}
                className="bg-brand-700 text-white px-5 py-2.5 rounded-lg hover:bg-brand-800 flex items-center gap-2 text-sm font-medium transition-colors shadow-sm"
              >
                <Plus size={18} /> Ajouter un livre
              </button>
            </div>

            {showAddBook && (
              <form onSubmit={handleCreateBook} className="bg-white p-8 rounded-xl border border-brand-200 shadow-sm grid gap-6 grid-cols-1 md:grid-cols-2">
                <h4 className="md:col-span-2 font-bold text-lg text-brand-800 mb-2">Nouveau Livre</h4>
                <div className="space-y-1">
                    <label className="text-sm font-semibold text-stone-600">Titre</label>
                    <input required className="w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" placeholder="Ex: Les Misérables" value={newBook.title} onChange={e => setNewBook({...newBook, title: e.target.value})} />
                </div>
                <div className="space-y-1">
                    <label className="text-sm font-semibold text-stone-600">Auteur</label>
                    <input required className="w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" placeholder="Ex: Victor Hugo" value={newBook.author} onChange={e => setNewBook({...newBook, author: e.target.value})} />
                </div>
                <div className="space-y-1">
                    <label className="text-sm font-semibold text-stone-600">Catégorie</label>
                    <input className="w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" placeholder="Ex: Classique" value={newBook.category} onChange={e => setNewBook({...newBook, category: e.target.value})} />
                </div>
                <div className="space-y-1">
                    <label className="text-sm font-semibold text-stone-600">Nombre de copies</label>
                    <input type="number" min="1" className="w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" placeholder="1" value={newBook.totalCopies} onChange={e => setNewBook({...newBook, totalCopies: parseInt(e.target.value)})} />
                </div>
                <div className="md:col-span-2 space-y-1">
                    <label className="text-sm font-semibold text-stone-600">Description</label>
                    <textarea className="w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none" placeholder="Synopsis du livre..." rows={3} value={newBook.description} onChange={e => setNewBook({...newBook, description: e.target.value})} />
                </div>
                <div className="md:col-span-2 flex justify-end gap-3 mt-2">
                   <button type="button" onClick={() => setShowAddBook(false)} className="px-5 py-2.5 text-stone-600 hover:bg-stone-100 rounded-lg font-medium transition-colors">Annuler</button>
                   <button type="submit" className="px-5 py-2.5 bg-brand-700 text-white rounded-lg font-medium hover:bg-brand-800 transition-colors">Enregistrer le livre</button>
                </div>
              </form>
            )}

            <div className="bg-white shadow-sm overflow-hidden border border-brand-200 rounded-xl">
              <table className="min-w-full divide-y divide-brand-100">
                <thead className="bg-brand-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-bold text-stone-500 uppercase tracking-wider">Titre</th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-stone-500 uppercase tracking-wider">Auteur</th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-stone-500 uppercase tracking-wider">Copies (Dispo / Total)</th>
                    <th className="px-6 py-4 text-right text-xs font-bold text-stone-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-brand-100">
                  {books.map(book => (
                    <tr key={book.id} className="hover:bg-brand-50/30 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-brand-900">{book.title}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-stone-600">{book.author}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-stone-600">
                        <span className={`font-bold ${book.availableCopies === 0 ? 'text-red-600' : 'text-green-700'}`}>{book.availableCopies}</span> 
                        <span className="text-stone-400 mx-1">/</span> 
                        {book.totalCopies}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button onClick={() => handleDeleteBook(book.id)} className="text-red-500 hover:text-red-700 p-2 hover:bg-red-50 rounded-full transition-colors">
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'reservations' && (
          <div className="space-y-6">
             <div className="bg-white shadow-sm overflow-hidden border border-brand-200 rounded-xl">
              <table className="min-w-full divide-y divide-brand-100">
                <thead className="bg-brand-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-bold text-stone-500 uppercase tracking-wider">Utilisateur</th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-stone-500 uppercase tracking-wider">Livre</th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-stone-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-stone-500 uppercase tracking-wider">Statut</th>
                    <th className="px-6 py-4 text-right text-xs font-bold text-stone-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-brand-100">
                  {reservations.map(res => (
                    <tr key={res.id} className="hover:bg-brand-50/30 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-brand-900">{res.userName}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-stone-600">{res.bookTitle}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-stone-500">{new Date(res.date).toLocaleDateString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={`px-3 py-1 inline-flex text-xs leading-5 font-bold rounded-full ${res.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-stone-100 text-stone-600'}`}>
                          {res.status === 'active' ? 'En cours' : 'Retourné'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {res.status === 'active' && (
                          <button 
                            onClick={() => handleReturnBook(res.id)}
                            className="text-brand-600 hover:text-brand-900 flex items-center justify-end gap-1 w-full font-bold hover:underline"
                          >
                            <RotateCcw size={16} /> Marquer retourné
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
