import React, { useEffect, useState } from 'react';
import { db } from '../services/mockDatabase';
import { Book } from '../types';
import { Search, Filter, Info, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';
import AIAssistant from '../components/AIAssistant';

const Catalog: React.FC = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Toutes');
  const [categories, setCategories] = useState<string[]>(['Toutes']);

  useEffect(() => {
    const fetchBooks = async () => {
      const data = await db.getBooks();
      setBooks(data);
      const uniqueCats = Array.from(new Set(data.map(b => b.category)));
      setCategories(['Toutes', ...uniqueCats]);
      setLoading(false);
    };
    fetchBooks();
  }, []);

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          book.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'Toutes' || book.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-brand-100">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <h2 className="text-3xl font-serif font-bold text-brand-900">Le Catalogue</h2>
            <p className="text-stone-600 mt-2">Découvrez nos ouvrages disponibles à la réservation.</p>
          </div>
          
          {/* Search & Filter Controls */}
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-brand-400 group-hover:text-brand-600 transition-colors" size={18} />
              <input 
                type="text" 
                placeholder="Rechercher un titre..." 
                className="pl-10 pr-4 py-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 w-full bg-brand-50/50 transition-all shadow-sm"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="relative group">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-brand-400 group-hover:text-brand-600 transition-colors" size={18} />
              <select 
                className="pl-10 pr-10 py-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 w-full appearance-none bg-brand-50/50 cursor-pointer shadow-sm text-stone-700"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
              </select>
            </div>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-24">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
        </div>
      ) : filteredBooks.length === 0 ? (
        <div className="text-center py-24 bg-white rounded-2xl border border-dashed border-brand-200">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-brand-50 mb-4">
            <Info className="h-8 w-8 text-brand-400" />
          </div>
          <h3 className="text-lg font-medium text-brand-900">Aucun résultat trouvé</h3>
          <p className="text-stone-500 mt-1">Essayez de modifier vos critères de recherche.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredBooks.map(book => (
            <div key={book.id} className="group bg-white rounded-xl shadow-sm border border-brand-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col h-full">
              <div className="aspect-[2/3] overflow-hidden bg-stone-200 relative">
                <img 
                  src={book.coverUrl} 
                  alt={book.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                   <span className="text-white text-sm font-medium">{book.category}</span>
                </div>
              </div>
              <div className="p-5 flex flex-col flex-grow">
                <h3 className="font-serif font-bold text-lg text-brand-900 line-clamp-1 mb-1" title={book.title}>{book.title}</h3>
                <p className="text-stone-600 text-sm italic mb-3">de {book.author}</p>
                <p className="text-stone-500 text-sm line-clamp-3 mb-4 flex-grow leading-relaxed">{book.description}</p>
                
                <div className="mt-auto pt-4 border-t border-brand-50 flex items-center justify-between">
                  <div className={`text-xs font-semibold px-2 py-1 rounded ${book.availableCopies > 0 ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100'}`}>
                    {book.availableCopies > 0 ? `${book.availableCopies} en rayon` : 'Indisponible'}
                  </div>
                  <Link 
                    to={`/book/${book.id}`}
                    className="text-brand-600 hover:text-brand-800 text-sm font-bold uppercase tracking-wide flex items-center gap-1 group/link"
                  >
                    Voir
                    <BookOpen size={14} className="group-hover/link:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Include the AI Assistant */}
      <AIAssistant catalog={books} />
    </div>
  );
};

export default Catalog;
