import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, Mail, Library } from 'lucide-react';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await login(email, password);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Erreur de connexion');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10">
      <div className="bg-white p-8 md:p-10 border border-brand-100 rounded-2xl shadow-xl">
        <div className="text-center mb-8">
          <div className="inline-flex justify-center items-center p-3 bg-brand-50 rounded-full mb-4 text-brand-600">
             <Library size={32} />
          </div>
          <h2 className="text-2xl font-serif font-bold text-brand-900">Connexion KtabGo</h2>
          <p className="text-stone-500 mt-2">Accédez à votre espace personnel</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm mb-6 border border-red-100">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-stone-700 mb-2">Adresse Email</label>
            <div className="relative group">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 group-hover:text-brand-500 transition-colors" size={18} />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-brand-50/30 transition-all outline-none"
                placeholder="votre@email.com"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-stone-700 mb-2">Mot de passe</label>
            <div className="relative group">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 group-hover:text-brand-500 transition-colors" size={18} />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-brand-50/30 transition-all outline-none"
                placeholder="••••••••"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-brand-600 text-white py-3 rounded-lg font-bold hover:bg-brand-700 transition-all shadow-md hover:shadow-lg mt-2"
          >
            Se connecter
          </button>
        </form>

        <div className="mt-8 text-center text-sm border-t border-brand-100 pt-6">
          <span className="text-stone-600">Pas encore de compte ? </span>
          <Link to="/register" className="text-brand-700 font-bold hover:underline hover:text-brand-900 transition-colors">
            Créer un compte
          </Link>
        </div>
        
        <div className="mt-6 p-4 bg-stone-50 rounded-lg text-xs text-stone-500 text-center border border-stone-100">
          <p className="font-semibold mb-1">Comptes de démonstration :</p>
          <p>Admin: admin@ktabgo.ma / admin</p>
          <p>Utilisateur: jean@test.fr / user</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
