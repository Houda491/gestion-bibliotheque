import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, Mail, User, BookOpen } from 'lucide-react';

const Register: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await register(name, email, password);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Erreur lors de l\'inscription');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10">
      <div className="bg-white p-8 md:p-10 border border-brand-100 rounded-2xl shadow-xl">
        <div className="text-center mb-8">
          <div className="inline-flex justify-center items-center p-3 bg-brand-50 rounded-full mb-4 text-brand-600">
             <BookOpen size={32} />
          </div>
          <h2 className="text-2xl font-serif font-bold text-brand-900">Bienvenue sur KtabGo</h2>
          <p className="text-stone-500 mt-2">Rejoignez la communauté des lecteurs</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm mb-6 border border-red-100">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-stone-700 mb-2">Nom complet</label>
            <div className="relative group">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 group-hover:text-brand-500 transition-colors" size={18} />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-10 w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-brand-50/30 transition-all outline-none"
                placeholder="Jean Dupont"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-stone-700 mb-2">Adresse Email</label>
            <div className="relative group">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 group-hover:text-brand-500 transition-colors" size={18} />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10 w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-brand-50/30 transition-all outline-none"
                placeholder="votre@email.com"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-stone-700 mb-2">Mot de passe</label>
            <div className="relative group">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 group-hover:text-brand-500 transition-colors" size={18} />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 w-full p-3 border border-brand-200 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-brand-50/30 transition-all outline-none"
                placeholder="••••••••"
                minLength={4}
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-brand-600 text-white py-3 rounded-lg font-bold hover:bg-brand-700 transition-all shadow-md hover:shadow-lg mt-2"
          >
            S'inscrire
          </button>
        </form>

        <div className="mt-8 text-center text-sm border-t border-brand-100 pt-6">
          <span className="text-stone-600">Déjà inscrit ? </span>
          <Link to="/login" className="text-brand-700 font-bold hover:underline hover:text-brand-900 transition-colors">
            Connectez-vous
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
