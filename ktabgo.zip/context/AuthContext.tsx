import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole } from '../types';
import { db } from '../services/mockDatabase';

interface AuthContextType {
  user: User | null;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for persisted session
    const storedUser = localStorage.getItem('biblio_session');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    db.init(); // Ensure DB is ready
    setIsLoading(false);
  }, []);

  const login = async (email: string, pass: string) => {
    const users = await db.getUsers();
    const foundUser = users.find(u => u.email === email && u.password === pass);
    
    if (foundUser) {
      // Remove password from state for security
      const { password, ...safeUser } = foundUser; 
      setUser(safeUser as User);
      localStorage.setItem('biblio_session', JSON.stringify(safeUser));
    } else {
      throw new Error("Email ou mot de passe incorrect.");
    }
  };

  const register = async (name: string, email: string, pass: string) => {
    const newUser: User = {
      id: Date.now().toString(),
      name,
      email,
      password: pass,
      role: UserRole.USER,
      registeredAt: new Date().toISOString()
    };
    await db.createUser(newUser);
    // Auto login
    await login(email, pass);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('biblio_session');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
