import React, { useState } from 'react';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { BookOpen, User, LogOut, Menu, X, Library } from 'lucide-react';

const Layout: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    setIsMenuOpen(false);
  };

  const isActive = (path: string) => location.pathname === path 
    ? "text-brand-800 font-bold border-b-2 border-brand-600" 
    : "text-stone-600 hover:text-brand-700 transition-colors";

  return (
    <div className="min-h-screen flex flex-col font-sans text-stone-800 bg-brand-50">
      {/* Navbar */}
      <nav className="bg-white shadow-md sticky top-0 z-50 border-b border-brand-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              <Link to="/" className="flex-shrink-0 flex items-center gap-3 group">
                <div className="bg-brand-500 p-2 rounded-lg text-white group-hover:bg-brand-600 transition-colors shadow-sm">
                  <Library className="h-6 w-6" />
                </div>
                <span className="font-serif font-bold text-2xl text-brand-900 tracking-tight">KtabGo</span>
              </Link>
              <div className="hidden md:ml-10 md:flex md:space-x-8">
                <Link to="/" className={`inline-flex items-center px-1 pt-1 text-sm ${isActive('/')}`}>Accueil</Link>
                <Link to="/catalog" className={`inline-flex items-center px-1 pt-1 text-sm ${isActive('/catalog')}`}>Catalogue</Link>
                {user && <Link to="/profile" className={`inline-flex items-center px-1 pt-1 text-sm ${isActive('/profile')}`}>Mes Réservations</Link>}
                {user?.role === UserRole.ADMIN && (
                  <Link to="/admin" className={`inline-flex items-center px-1 pt-1 text-sm ${isActive('/admin')}`}>Administration</Link>
                )}
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-4">
              {user ? (
                <div className="flex items-center gap-4">
                  <span className="text-sm font-medium text-brand-800 bg-brand-50 px-3 py-1 rounded-full border border-brand-200">
                    Bonjour, {user.name}
                  </span>
                  <button 
                    onClick={handleLogout}
                    className="flex items-center gap-2 px-4 py-2 border border-brand-200 text-sm font-medium rounded-md text-brand-700 bg-white hover:bg-brand-50 hover:text-brand-900 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500"
                  >
                    <LogOut size={16} />
                    Déconnexion
                  </button>
                </div>
              ) : (
                <div className="flex gap-3">
                  <Link to="/login" className="px-4 py-2 text-sm font-medium text-brand-800 hover:text-brand-600 transition-colors">Connexion</Link>
                  <Link to="/register" className="px-5 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-brand-600 hover:bg-brand-700 shadow-sm transition-colors">Inscription</Link>
                </div>
              )}
            </div>

            <div className="flex items-center md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-brand-700 hover:bg-brand-50 rounded-md">
                {isMenuOpen ? <X /> : <Menu />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-b border-brand-100 shadow-lg">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 flex flex-col">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-brand-800 hover:bg-brand-50">Accueil</Link>
              <Link to="/catalog" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-brand-800 hover:bg-brand-50">Catalogue</Link>
              {user && <Link to="/profile" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-brand-800 hover:bg-brand-50">Mes Réservations</Link>}
              {user?.role === UserRole.ADMIN && (
                <Link to="/admin" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-brand-800 hover:bg-brand-50">Administration</Link>
              )}
              <div className="border-t border-brand-100 mt-2 pt-2">
                {user ? (
                  <button onClick={handleLogout} className="w-full text-left px-3 py-2 text-red-600 font-medium hover:bg-red-50 rounded-md">Déconnexion</button>
                ) : (
                  <>
                    <Link to="/login" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 text-brand-700 font-medium hover:bg-brand-50 rounded-md">Connexion</Link>
                    <Link to="/register" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 text-brand-800 font-medium hover:bg-brand-50 rounded-md">Inscription</Link>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </nav>

      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <Outlet />
      </main>

      <footer className="bg-brand-900 text-brand-100 mt-auto border-t border-brand-800">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Library className="h-6 w-6 text-brand-300" />
                <span className="font-serif font-bold text-xl text-white">KtabGo</span>
              </div>
              <p className="text-brand-200 text-sm leading-relaxed">
                Votre bibliothèque numérique de nouvelle génération. L'élégance du papier, la simplicité du digital.
              </p>
            </div>
            <div>
              <h4 className="font-serif font-bold text-lg text-white mb-4">Liens Rapides</h4>
              <ul className="space-y-2 text-sm text-brand-200">
                <li><Link to="/catalog" className="hover:text-white transition-colors">Catalogue</Link></li>
                <li><Link to="/register" className="hover:text-white transition-colors">Devenir membre</Link></li>
                <li><Link to="/login" className="hover:text-white transition-colors">Espace membre</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-serif font-bold text-lg text-white mb-4">Contact</h4>
              <p className="text-brand-200 text-sm">123 Avenue des Livres, Rabat</p>
              <p className="text-brand-200 text-sm">contact@ktabgo.ma</p>
            </div>
          </div>
          <div className="border-t border-brand-800 pt-6 text-center">
            <p className="text-brand-400 text-sm">
              © {new Date().getFullYear()} KtabGo. Tous droits réservés.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
